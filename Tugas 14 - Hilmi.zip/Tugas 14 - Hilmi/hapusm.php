<?php
if (isset($_GET['id'])) {
    include('koneksim.php');
    $npm = $_GET['id'];
    $del = mysqli_query($koneksi, "DELETE FROM tb_mahasiswaa WHERE npm='$npm'");
    if ($del) {
        echo 'Data barang berhasil dihapus! ';
        echo '<a href="list_mahasiswa.php">Kembali</a>';
    } else {
        echo 'Gagal menghapus data! ';
        echo '<a href="list_mahasiswa.php">Kembali</a>';
    }
}
