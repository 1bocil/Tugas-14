<!DOCTYPE html>
<html>

<head>
    <title>Upload File </title>
</head>

<body>
    <h1>Upload File </h1>
    <?php
    include 'koneksim.php';
    if (isset($_POST["save"])) {
        // menangkap data yang di kirim dari form
        $npm = $_POST['npm'];
        $nama = $_POST['nama'];
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $jurusan = $_POST['jurusan'];
        $kelas = $_POST['kelas'];

        $ekstensi_diperbolehkan = array('png', 'jpg', 'jpeg');
        $photo = $_FILES['gambar']['name'];

        $x = explode('.', $photo);
        $ekstensi = strtolower(end($x));
        $ukuran = $_FILES['gambar']['size'];

        $file_tmp = $_FILES['gambar']['tmp_name'];
        $namafile = 'img_' . $npm . '.' . $ekstensi;

        if (in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
            if ($ukuran < 2044070) {
                move_uploaded_file($file_tmp, 'file/' . $namafile);
                $query = mysqli_query($koneksi, "insert into tb_mahasiswaa (npm,nama,jenis_kelamin,jurusan,kelas,gambar) values ('$npm','$nama','$jenis_kelamin','$jurusan','$kelas','$namafile')");
                if ($query) {
                    echo "<script>alert('DATA BERHASIL DI SIMPAN');window.location='index.php';</script>";
                } else {
                    echo "<script>alert('GAGAL MENGUPLOAD GAMBAR');window.location='index.php';</script>";
                }
            } else {
                echo "<script>alert('UKURAN FILE TERLALU BESAR');window.location='tambahmhs.php';</script>";
            }
        } else {
            echo "<script>alert('EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN');window.location='tambahmhs.php';</script>";
        }
    }
